# SYNQORIA — Autonomous engineering baseline v0.1.0

**Africa medical intelligence synchronized**

This is a **verified specification/register and build-orchestration baseline**, not implemented clinical software, screenshots or a certified hospital application. It includes the two prior authoritative design documents, 40-module and 261-screen canonical JSON registers, 20-phase roadmap, hourly batch protocol, visual/navigation rules, mobile product contract and an executable register integrity check.

Read `docs/program/STATUS.md` first, then `docs/program/BATCH_PROTOCOL.md`, then the two authority documents.

Use `python tests/test_baseline.py` to validate canonical scope and planned module coverage. Tests verify the *planning package only*.

The `apps/` and `services/` directories reserve architecture ownership; no unverified clinical implementation has been synthesized simply to inflate progress. Actual code should be built from the highest dependency-unblocked phase, with cumulative artifact verification per run.
